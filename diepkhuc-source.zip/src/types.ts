export interface UserPresence {
  id: string;
  name: string;
  avatar: string;
  role: 'host' | 'vip' | 'mod' | 'member';
  vipTier?: 'none' | 'silver' | 'gold' | 'diamond';
  isMuted: boolean;
  hasVideo: boolean;
  hasAudio: boolean;
  isStreaming: boolean;
  isCamOn?: boolean;
  camAllowedViewers?: string[]; // user IDs allowed to view their cam
  camAutoAccept?: boolean;
}

export interface MicQueueItem {
  userId: string;
  userName: string;
  avatar: string;
  role: string;
  vipTier?: string;
  queuedAt: number;
}

export interface GiftItem {
  id: string;
  name: string;
  icon: string;
  value: number;
  effect: 'float_heart' | 'rose_storm' | 'golden_crown' | 'supercar' | 'mega_yacht';
}

export interface ChatMessage {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  role: string;
  vipTier?: string;
  avatar: string;
  text: string;
  type: 'chat' | 'system' | 'gift' | 'action';
  gift?: {
    id: string;
    name: string;
    icon: string;
    value: number;
  };
  timestamp: number;
}

export interface PrivateMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  receiverId: string;
  receiverName: string;
  text: string;
  timestamp: number;
}

export interface CamViewRequest {
  requestId: string;
  requesterId: string;
  requesterName: string;
  requesterAvatar: string;
  broadcasterId: string;
  timestamp: number;
}

export interface SongLyricLine {
  time: number;
  text: string;
}

export interface SongItem {
  id: string;
  title: string;
  artist: string;
  genre: 'Bolero' | 'Trữ Tình' | 'Nhạc Trẻ' | 'Dân Ca' | 'Remix';
  tempo: number;
  key: string;
  duration: number;
  lyrics: SongLyricLine[];
}

export interface RoomSummary {
  id: string;
  name: string;
  topic: string;
  category: string;
  hostName: string;
  isLocked: boolean;
  maxMicMinutes: number;
  userCount: number;
  queueCount: number;
  activeSinger: string | null;
  openCamCount?: number;
}

export interface RoomDetail {
  id: string;
  name: string;
  topic: string;
  category: string;
  hostId: string;
  hostName: string;
  isLocked: boolean;
  maxMicMinutes: number;
  activeMicUser: UserPresence | null;
  activeCoMicUser: UserPresence | null;
  micStartedAt: number | null;
  micQueue: MicQueueItem[];
  userCount: number;
  users: UserPresence[];
  messages: ChatMessage[];
  currentSong: {
    id: string;
    title: string;
    artist: string;
    isPlaying: boolean;
    currentTime: number;
    updatedAt: number;
  } | null;
}

export interface RegisteredAccount {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  role: 'host' | 'vip' | 'mod' | 'member';
  vipTier: 'none' | 'silver' | 'gold' | 'diamond';
  createdAt: number;
  coins: number;
}
