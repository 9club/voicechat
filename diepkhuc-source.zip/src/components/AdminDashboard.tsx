import React, { useState, useEffect } from 'react';
import {
  Shield, Users, Radio, Clock, Settings, Trash2, RotateCcw,
  Crown, UserCheck, AlertTriangle, Search, Check, Filter, Flame
} from 'lucide-react';
import { wsClient } from '../services/websocket';

interface AdminDashboardProps {
  onClose: () => void;
  onJoinRoom: (roomId: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose, onJoinRoom }) => {
  const [activeTab, setActiveTab] = useState<'rooms' | 'users'>('rooms');
  const [rooms, setRooms] = useState<any[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [notification, setNotification] = useState<string | null>(null);

  // Selected room for editing
  const [editingRoomId, setEditingRoomId] = useState<string | null>(null);
  const [editMicMinutes, setEditMicMinutes] = useState<number>(5);
  const [editRoomName, setEditRoomName] = useState<string>('');

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  useEffect(() => {
    wsClient.adminGetAllData();

    const unsub = wsClient.on('admin_data_response', (data) => {
      if (data.rooms) setRooms(data.rooms);
      if (data.onlineUsers) setOnlineUsers(data.onlineUsers);
      if (data.accounts) setAccounts(data.accounts);
    });

    const interval = setInterval(() => {
      wsClient.adminGetAllData();
    }, 4000);

    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  const handleUpdateMicMinutes = (roomId: string, minutes: number) => {
    wsClient.adminManageRoom(roomId, 'update', { maxMicMinutes: minutes });
    showToast(`Đã cập nhật thời gian mic phòng thành ${minutes} phút!`);
    wsClient.adminGetAllData();
  };

  const handleResetMic = (roomId: string) => {
    wsClient.adminManageRoom(roomId, 'reset_mic');
    showToast('Đã thu hồi mic và giải phóng sân khấu!');
    wsClient.adminGetAllData();
  };

  const handleClearQueue = (roomId: string) => {
    wsClient.adminManageRoom(roomId, 'clear_queue');
    showToast('Đã xóa danh sách xếp hàng mic!');
    wsClient.adminGetAllData();
  };

  const handleDeleteRoom = (roomId: string, name: string) => {
    if (window.confirm(`Bạn có chắc muốn xóa phòng "${name}" không?`)) {
      wsClient.adminManageRoom(roomId, 'delete');
      showToast(`Đã xóa phòng "${name}"!`);
      wsClient.adminGetAllData();
    }
  };

  const handleChangeUserRole = (userId: string, role: string, vipTier?: string) => {
    wsClient.adminManageUser(userId, 'set_role', role, vipTier);
    showToast(`Đã cập nhật chức vụ thành viên!`);
    wsClient.adminGetAllData();
  };

  const handleKickUser = (userId: string, userName: string) => {
    if (window.confirm(`Mời thành viên "${userName}" ra khỏi phòng?`)) {
      wsClient.adminManageUser(userId, 'kick');
      showToast(`Đã mời "${userName}" rời khỏi phòng!`);
      wsClient.adminGetAllData();
    }
  };

  const filteredRooms = rooms.filter(r =>
    r.name.toLowerCase().includes(search.toLowerCase()) ||
    r.category.toLowerCase().includes(search.toLowerCase()) ||
    r.hostName.toLowerCase().includes(search.toLowerCase())
  );

  const filteredUsers = onlineUsers.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.role.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 w-full space-y-6">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 font-bold text-xs shadow-2xl animate-in slide-in-from-top-4">
          ✨ {notification}
        </div>
      )}

      {/* Header & Metrics */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0e1322] border border-slate-800 rounded-2xl p-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black text-white tracking-wide">
                Trung Tâm Quản Trị Hệ Thống Điệp Khúc
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                ADMIN MASTER
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Quản lý tất cả phòng hát trực tiếp, điều chỉnh thời gian mic và phân quyền thành viên
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition-colors self-start md:self-auto"
        >
          Quay lại Sảnh Chờ
        </button>
      </div>

      {/* Live System Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-[#0f1424] border border-slate-800 rounded-xl p-4 space-y-1">
          <span className="text-[11px] text-slate-400 font-semibold uppercase">Tổng Số Phòng</span>
          <div className="text-2xl font-black text-white">{rooms.length}</div>
          <span className="text-[10px] text-emerald-400 font-medium">● Hoạt động 24/7</span>
        </div>
        <div className="bg-[#0f1424] border border-slate-800 rounded-xl p-4 space-y-1">
          <span className="text-[11px] text-slate-400 font-semibold uppercase">Thành Viên Trực Tuyến</span>
          <div className="text-2xl font-black text-amber-400">{onlineUsers.length}</div>
          <span className="text-[10px] text-slate-400">Kết nối thời gian thực</span>
        </div>
        <div className="bg-[#0f1424] border border-slate-800 rounded-xl p-4 space-y-1">
          <span className="text-[11px] text-slate-400 font-semibold uppercase">Ca Sĩ Đang Hát</span>
          <div className="text-2xl font-black text-rose-400">
            {rooms.filter(r => r.activeSinger).length}
          </div>
          <span className="text-[10px] text-slate-400">Đang giữ micro</span>
        </div>
        <div className="bg-[#0f1424] border border-slate-800 rounded-xl p-4 space-y-1">
          <span className="text-[11px] text-slate-400 font-semibold uppercase">Hội Viên VIP Đăng Ký</span>
          <div className="text-2xl font-black text-indigo-400">{accounts.length}</div>
          <span className="text-[10px] text-amber-300 font-medium">Bạc / Vàng / Kim Cương</span>
        </div>
      </div>

      {/* Navigation Tabs & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('rooms')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'rooms'
                ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Quản Lý Phòng Hát ({rooms.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'users'
                ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Quản Lý Thành Viên ({onlineUsers.length})</span>
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={activeTab === 'rooms' ? 'Tìm phòng hát...' : 'Tìm thành viên...'}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Tab 1: Rooms Management */}
      {activeTab === 'rooms' ? (
        <div className="grid grid-cols-1 gap-4">
          {filteredRooms.map((room) => (
            <div
              key={room.id}
              className="bg-[#0f1424] border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all flex flex-col md:flex-row md:items-center justify-between gap-5"
            >
              <div className="space-y-2 max-w-xl">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold text-[10px]">
                    {room.category}
                  </span>
                  <h2 className="text-base font-bold text-white">{room.name}</h2>
                  {room.isLocked && (
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300">
                      Có Mật Khẩu
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-400">{room.topic}</p>

                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
                  <span>Chủ phòng: <strong className="text-slate-200">{room.hostName}</strong></span>
                  <span>·</span>
                  <span>Số người: <strong className="text-amber-400">{room.userCount}</strong></span>
                  <span>·</span>
                  <span>Hàng chờ mic: <strong className="text-indigo-400">{room.queueCount}</strong></span>
                  <span>·</span>
                  <span>
                    Đang hát:{' '}
                    {room.activeSinger ? (
                      <strong className="text-emerald-400">🎤 {room.activeSinger}</strong>
                    ) : (
                      <span className="text-slate-500">Trống</span>
                    )}
                  </span>
                </div>
              </div>

              {/* Dynamic Mic Timer Controls & Actions */}
              <div className="flex flex-wrap items-center gap-3 shrink-0 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                {/* Change Mic Time */}
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[11px] text-slate-300 font-medium">Thời gian mic:</span>
                  <select
                    value={room.maxMicMinutes}
                    onChange={(e) => handleUpdateMicMinutes(room.id, Number(e.target.value))}
                    className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-xs text-amber-300 font-bold focus:outline-none focus:border-amber-400"
                  >
                    <option value={1}>1 phút (Hát thử)</option>
                    <option value={2}>2 phút</option>
                    <option value={3}>3 phút (Nhanh)</option>
                    <option value={5}>5 phút (Chuẩn)</option>
                    <option value={8}>8 phút</option>
                    <option value={10}>10 phút (DJ)</option>
                  </select>
                </div>

                <button
                  onClick={() => handleResetMic(room.id)}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors flex items-center gap-1"
                  title="Thu hồi mic hiện tại"
                >
                  <RotateCcw className="w-3 h-3 text-amber-400" />
                  <span>Thu Hồi Mic</span>
                </button>

                <button
                  onClick={() => handleClearQueue(room.id)}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                  title="Xóa hàng chờ mic"
                >
                  Xóa Hàng
                </button>

                <button
                  onClick={() => onJoinRoom(room.id)}
                  className="px-3 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold transition-colors"
                >
                  Vào Phòng
                </button>

                <button
                  onClick={() => handleDeleteRoom(room.id, room.name)}
                  className="p-1 rounded-lg text-slate-500 hover:text-rose-400 transition-colors"
                  title="Xóa phòng này"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Tab 2: Users Management */
        <div className="bg-[#0f1424] border border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-800">
              <thead className="bg-[#0b0f1a] text-slate-400 font-bold uppercase text-[10px]">
                <tr>
                  <th className="px-4 py-3">Thành Viên</th>
                  <th className="px-4 py-3">Chức Vụ</th>
                  <th className="px-4 py-3">Cấp Độ VIP</th>
                  <th className="px-4 py-3">Vị Trí Hiện Tại</th>
                  <th className="px-4 py-3 text-right">Hành Động Quản Trị</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-800 border border-slate-700 shrink-0">
                          {user.avatar ? (
                            <img src={user.avatar} alt={user.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center font-bold text-slate-400">
                              {user.name.charAt(0)}
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-white">{user.name}</div>
                          <div className="text-[10px] text-slate-500 font-mono">{user.id}</div>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={user.role}
                        onChange={(e) => handleChangeUserRole(user.id, e.target.value, user.vipTier)}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                      >
                        <option value="member">Thành Viên</option>
                        <option value="vip">VIP Star</option>
                        <option value="mod">Trọng Tài (Mod)</option>
                        <option value="host">Quản Trị Viên (Host)</option>
                      </select>
                    </td>

                    <td className="px-4 py-3">
                      <select
                        value={user.vipTier || 'none'}
                        onChange={(e) => handleChangeUserRole(user.id, user.role, e.target.value)}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-amber-300 font-semibold focus:outline-none focus:border-amber-400"
                      >
                        <option value="none">Thường (none)</option>
                        <option value="silver">🥈 VIP Bạc</option>
                        <option value="gold">🌟 VIP Vàng</option>
                        <option value="diamond">👑 VIP Kim Cương</option>
                      </select>
                    </td>

                    <td className="px-4 py-3">
                      {user.roomId ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 text-[11px] font-medium">
                          Trong phòng #{user.roomId}
                        </span>
                      ) : (
                        <span className="text-slate-500 text-[11px]">Tại sảnh chờ</span>
                      )}
                    </td>

                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleKickUser(user.id, user.name)}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-semibold text-[11px] transition-colors"
                        >
                          Mời Ra Khỏi Phòng
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
