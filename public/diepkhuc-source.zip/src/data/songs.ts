import { SongItem } from '../types';

export const KARAOKE_SONGS: SongItem[] = [
  {
    id: 'song-duyenphan',
    title: 'Duyên Phận',
    artist: 'Như Quỳnh / Thái Châu',
    genre: 'Bolero',
    tempo: 82,
    key: 'Am',
    duration: 220,
    lyrics: [
      { time: 4, text: 'Phận là con gái chưa một lần yêu ai' },
      { time: 10, text: 'Nhìn về tương lai mà thấy như sông rộng dài' },
      { time: 17, text: 'Cảnh nhà neo đơn, đàn em chưa lớn' },
      { time: 24, text: 'Trĩu đôi vai gánh nặng từng ngày' },
      { time: 31, text: 'Mẹ già đau yếu, sớm hôm hao gầy' },
      { time: 38, text: 'Tuổi xuân con gái cũng qua như mây bay' },
      { time: 46, text: 'Đêm nay mưa gió bão bùng ngoài hiên' },
      { time: 54, text: 'Nghe từng giọt rớt mà lòng xót xa triền miên' },
      { time: 62, text: 'Thương mẹ thương em thương đời cơ hàn' },
      { time: 70, text: 'Mong mai sau ấm êm một mái nhà...' }
    ]
  },
  {
    id: 'song-sautim',
    title: 'Sầu Tím Thiệp Hồng',
    artist: 'Quang Lê & Lệ Quyên',
    genre: 'Bolero',
    tempo: 78,
    key: 'Dm',
    duration: 210,
    lyrics: [
      { time: 4, text: 'Từ lúc quen nhau chưa nói một lời gì' },
      { time: 11, text: 'Tỏ ý cùng em chuyện lứa đôi mai sau' },
      { time: 18, text: 'Tôi sợ câu tơ duyên mong manh dễ vỡ' },
      { time: 26, text: 'Ngập ngừng e ấp sợ câu chối từ' },
      { time: 34, text: 'Để rồi một hôm em bước lên kiệu hoa' },
      { time: 42, text: 'Tôi đứng nhìn theo ngấn lệ tuôn trào' },
      { time: 50, text: 'Thiệp hồng trao tay màu sầu tím ngắt' },
      { time: 58, text: 'Trách duyên bẽ bàng hay trách lòng người...' }
    ]
  },
  {
    id: 'song-thanhphobuon',
    title: 'Thành Phố Buồn',
    artist: 'Chế Linh / Đan Nguyên',
    genre: 'Trữ Tình',
    tempo: 74,
    key: 'Em',
    duration: 200,
    lyrics: [
      { time: 5, text: 'Thành phố nào nhớ không em?' },
      { time: 12, text: 'Nơi chúng mình tìm phút êm đềm' },
      { time: 20, text: 'Thành phố nào vừa đi đã mỏi' },
      { time: 27, text: 'Đường quanh co quyện gốc thông già' },
      { time: 35, text: 'Con đường ngày xưa lá đổ bay bay' },
      { time: 43, text: 'Chiều nay sương khói giăng đầy lối xưa' },
      { time: 51, text: 'Đà Lạt ơi thấu chăng lòng kẻ ở' },
      { time: 59, text: 'Người đi biền biệt biết tìm nơi đâu...' }
    ]
  },
  {
    id: 'song-catdoi',
    title: 'Cắt Đôi Nỗi Sầu',
    artist: 'Tăng Duy Tân',
    genre: 'Remix',
    tempo: 124,
    key: 'Fm',
    duration: 180,
    lyrics: [
      { time: 3, text: 'Cắt đôi nỗi sầu anh buông tay' },
      { time: 7, text: 'Cắt đôi nỗi sầu thôi đắng cay' },
      { time: 11, text: 'Một mình trong đêm vắng với căn phòng' },
      { time: 15, text: 'Hết yêu thương rồi chẳng còn vấn vương' },
      { time: 20, text: 'Từng dòng tin nhắn vỡ tan mau' },
      { time: 25, text: 'Kỷ niệm xưa cũ hóa thương đau' },
      { time: 30, text: 'Thà là cô đơn để tim bình yên' },
      { time: 35, text: 'Quên đi bao nhiêu dối gian hẹn ước...' }
    ]
  },
  {
    id: 'song-bientinh',
    title: 'Biển Tình',
    artist: 'Tuấn Ngọc / Thanh Tuyền',
    genre: 'Trữ Tình',
    tempo: 80,
    key: 'C',
    duration: 205,
    lyrics: [
      { time: 4, text: 'Nằm nghe sóng vỗ từng lớp xa' },
      { time: 11, text: 'Bọt trời theo gió tràn trề dâng lên' },
      { time: 18, text: 'Trùng dương sóng vỗ đưa mây về ngàn' },
      { time: 26, text: 'Hồn anh lắng xuống bao nỗi niềm thương' },
      { time: 34, text: 'Biển ru khúc hát êm đềm tha thiết' },
      { time: 42, text: 'Gửi người em gái phương trời cách xa...' }
    ]
  }
];

export const VIRTUAL_GIFTS = [
  { id: 'rose', name: 'Hoa Hồng Đỏ', icon: '🌹', value: 10, effect: 'rose_storm' as const },
  { id: 'heart', name: 'Trái Tim Yêu', icon: '💖', value: 20, effect: 'float_heart' as const },
  { id: 'mic', name: 'Micro Vàng', icon: '🎤', value: 50, effect: 'golden_crown' as const },
  { id: 'beer', name: 'Ly Bia Nâng Cốc', icon: '🍻', value: 30, effect: 'float_heart' as const },
  { id: 'crown', name: 'Vương Miện Quý Tộc', icon: '👑', value: 100, effect: 'golden_crown' as const },
  { id: 'car', name: 'Siêu Xe Thể Thao', icon: '🏎️', value: 500, effect: 'supercar' as const },
  { id: 'yacht', name: 'Du Thuyền Hoàng Gia', icon: '🛥️', value: 1000, effect: 'mega_yacht' as const },
];
