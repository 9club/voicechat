import React, { useState } from 'react';
import {
  X, Music, Play, Pause, Square, Volume2, Search, Sliders, Check
} from 'lucide-react';
import { KARAOKE_SONGS } from '../data/songs';
import { SongItem } from '../types';

interface KaraokePlayerProps {
  isOpen: boolean;
  onClose: () => void;
  currentSong: {
    id: string;
    title: string;
    artist: string;
    isPlaying: boolean;
    currentTime: number;
    updatedAt: number;
  } | null;
  onSelectSong: (song: SongItem) => void;
  onTogglePlay: (isPlaying: boolean) => void;
  onStopSong: () => void;
}

export const KaraokePlayer: React.FC<KaraokePlayerProps> = ({
  isOpen,
  onClose,
  currentSong,
  onSelectSong,
  onTogglePlay,
  onStopSong
}) => {
  const [search, setSearch] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');

  if (!isOpen) return null;

  const genres = ['all', 'Bolero', 'Trữ Tình', 'Nhạc Trẻ', 'Remix'];

  const filteredSongs = KARAOKE_SONGS.filter(s => {
    const matchGenre = selectedGenre === 'all' || s.genre === selectedGenre;
    const matchSearch =
      s.title.toLowerCase().includes(search.toLowerCase()) ||
      s.artist.toLowerCase().includes(search.toLowerCase());
    return matchGenre && matchSearch;
  });

  const activeSong = currentSong ? KARAOKE_SONGS.find(s => s.id === currentSong.id) : null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0f1424] border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Music className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Dàn Nhạc Karaoke & Lời Bài Hát
              </h2>
              <p className="text-xs text-slate-400">
                Chọn nhạc đệm chất lượng cao cho phòng hát
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Active Song Player Bar */}
        {currentSong && activeSong && (
          <div className="bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-indigo-500/15 border-b border-amber-500/20 px-6 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                <Music className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <span>{activeSong.title}</span>
                  <span className="text-[10px] text-amber-400 px-1.5 py-0.5 rounded bg-amber-500/20">
                    {activeSong.genre}
                  </span>
                </div>
                <div className="text-[11px] text-slate-300">
                  {activeSong.artist} · Tempo: {activeSong.tempo} BPM · Tone: {activeSong.key}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onTogglePlay(!currentSong.isPlaying)}
                className="p-2 rounded-xl bg-amber-400 text-slate-950 font-bold hover:bg-amber-300 transition-colors"
                title={currentSong.isPlaying ? 'Tạm dừng' : 'Tiếp tục phát'}
              >
                {currentSong.isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
              </button>
              <button
                onClick={onStopSong}
                className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-rose-400 hover:bg-slate-700 transition-colors"
                title="Dừng nhạc"
              >
                <Square className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Search & Genre Filters */}
        <div className="p-4 border-b border-slate-800 space-y-3 bg-[#0d111e]">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Tìm bài hát, ca sĩ..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {genres.map(g => (
              <button
                key={g}
                onClick={() => setSelectedGenre(g)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedGenre === g
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {g === 'all' ? 'Tất Cả Thể Loại' : g}
              </button>
            ))}
          </div>
        </div>

        {/* Song List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 divide-y divide-slate-800/60">
          {filteredSongs.map(song => {
            const isCurrent = currentSong?.id === song.id;
            return (
              <div
                key={song.id}
                className={`pt-2 first:pt-0 flex items-center justify-between p-3 rounded-xl transition-all ${
                  isCurrent ? 'bg-amber-500/10 border border-amber-500/30' : 'hover:bg-slate-900/80'
                }`}
              >
                <div className="space-y-0.5">
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{song.title}</span>
                    {isCurrent && (
                      <span className="text-[10px] text-amber-300 font-medium px-2 py-0.5 rounded-full bg-amber-500/20">
                        Đang phát
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-400">
                    {song.artist} · <span className="text-amber-400/80">{song.genre}</span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    BPM: {song.tempo} · Tone: {song.key} · {Math.floor(song.duration / 60)}:{(song.duration % 60).toString().padStart(2, '0')}
                  </div>
                </div>

                <div>
                  {isCurrent ? (
                    <button
                      onClick={() => onTogglePlay(!currentSong.isPlaying)}
                      className="px-3.5 py-1.5 rounded-lg bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5"
                    >
                      {currentSong.isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                      <span>{currentSong.isPlaying ? 'Tạm Dừng' : 'Phát Tiếp'}</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => onSelectSong(song)}
                      className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-amber-400 hover:text-slate-950 text-slate-200 text-xs font-bold border border-slate-700 hover:border-amber-400 transition-all flex items-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Chọn Hát</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-[#0d111e] border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Hệ thống beat chuẩn tổng hợp Web Audio Stereo</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-lg transition-colors"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
